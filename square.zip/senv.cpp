#include "senv.h"

using namespace std;

void SLane::Present(u8 v) {
	if (v >= n)
		return;
	presCnt++;
	present |= Set::BitMask(v);

	missCnt--;
	missing &= ~Set::BitMask(v);
}

void SLane::Missing(u8 v) {
	if (v < n)
		return;
	missCnt++;
	missing &= ~(Set::BitMask(v));
}

bool SLane::Check() {
	if (presCnt + missCnt != n)
		return false;
	if ((present | missing) != all)
		return false;
	return true;
}

void SLane::AddBlank(int i, int j)
{
	pBlank = new BEntry();
	BStack[blankCnt] = pBlank;
	pBlank->SetCoords(i, j);
	blankCnt++;
}


bool SLane::PermuteStart()
{
	foundCnt = 0;

	// First level has 
	level = startLevel;
	pBlank = BStack[level];
	pBlank->selectedSet = preSelected;			// CountOne selected set
	pBlank->unSelected = missing - preSelected;	// All missing vals are needed
	pBlank->choiceSet = pBlank->miss - preSelected;	// Choose from all available candidates

	St.InitPass();

	return true;
}

bool SLane::PermuteStartStk()
{
	foundCnt = 0;

	// First level has 
	level = 0;
	pBlank = BStack[0];
	pBlank->selectedSet = 0;			// No selected set
	pBlank->unSelected = missing;	// All missing vals are needed
	pBlank->choiceSet = pBlank->miss;	// Choose from all available candidates

	St.InitPass();

	return true;
}

int SLane::ComputeAvail()
{
	BEntry* pEnt, *pDn;
	Set avail = 0;
	int dn = BEntry::BOT;
	pDn = NULL;
	preSelected = 0;

	for (int d = missCnt - 1; d >= 0; d--) {
		pEnt = BStack[d];
		pEnt->dnTrav = dn;

		if (pEnt->miss.CountIsOne()) {
			if (preSelected.Contains(pEnt->miss.mask)) {
				// Multiple forced single selections of same value: unviable
				return d;
			}

			pEnt->chosenBit = pEnt->miss.mask;
			preSelected += pEnt->chosenBit;
			//  FIX
			//avail += pEnt->miss;
			//pEnt->availForSelect = avail;
			pEnt->upTrav = d + 1;
		}
		else {
			if (pDn != NULL)
				pDn->upTrav = d;
			avail += pEnt->miss;
			pEnt->availForSelect = avail;
			pDn = pEnt;
			dn = d;
		}
	}
	if (pDn != NULL)
		pDn->upTrav = BEntry::TOP;
	else
		assert(0);
	startLevel = dn;
	return -1;
}

void SLane::PermuteContinueAt(int depth)
{
	level = depth;
	pBlank = BStack[level];
}

bool SLane::PermuteStep()
{
	St.Step();

	while (level >= 0) {
		// Entering level
		if (pBlank->choiceSet == 0) {				// Exhausted branch, or
			// Climb up
			level = pBlank->upTrav;
			pBlank = BStack[level];
			St.Exhaust();
		}
		else if ((pBlank->unSelected.mask
			!= (pBlank->availForSelect
				& pBlank->unSelected))) {	// Rest of permutation unviable
			// Climb up
			level = pBlank->upTrav;
			pBlank = BStack[level];
			St.Select();
		}
		else {
			// Extract candidate from choiceSet
			pBlank->chosenBit = pBlank->choiceSet.ExtractFirst();

			// Branch has a candidate
			if (pBlank->dnTrav == BEntry::BOT) {
				// Bottom branch: found a permutation
				assert(pBlank->choiceSet == 0);		//   Only one candidate should remain...
				foundCnt++;

				// Climb up
				level = pBlank->upTrav;
				pBlank = BStack[level];
				return true;
			}
			else {
				// Not bottom branch: add chosenBit to selected set for next level
				Mask chosen = pBlank->chosenBit;
				Mask nextselSet = pBlank->selectedSet | chosen;
				// ... and proceed down
				level = pBlank->dnTrav;
				pBlank = BStack[level];
				pBlank->selectedSet = nextselSet;
				pBlank->unSelected = missing - pBlank->selectedSet;
				pBlank->choiceSet = pBlank->miss & pBlank->unSelected;
			}
		}
	}

	// Iteration finished
	St.End();
	return false;
}

bool SLane::PermuteStepStk()
{
	St.Step();

	while (level >= 0) {
		// Entering level
		if (pBlank->choiceSet == 0) {				// Exhausted branch, or
			// Climb up
			pBlank = BStack[--level];
			St.Exhaust();
		}
		else if ((pBlank->unSelected.mask
			!= (pBlank->availForSelect
				& pBlank->unSelected))) {	// Rest of permutation unviable
			// Climb up
			pBlank = BStack[--level];
			St.Select();
		}
		else {
			// Extract candidate from choiceSet
			pBlank->chosenBit = pBlank->choiceSet.ExtractFirst();

			// Branch has a candidate
			if (level == missCnt - 1) {
				// Bottom branch: found one
				assert(pBlank->choiceSet == 0);		//   Only one candidate should remain...
				foundCnt++;

				// Climb up
				pBlank = BStack[--level];
				return true;
			}
			else {
				// Not bottom branch: add chosenBit to selected set for next level
				Mask chosen = pBlank->chosenBit;
				Mask nextselSet = pBlank->selectedSet | chosen;
				// ... and proceed down
				pBlank = BStack[++level];
				pBlank->selectedSet = nextselSet;
				pBlank->unSelected = missing - pBlank->selectedSet;
				pBlank->choiceSet = pBlank->miss & pBlank->unSelected;
			}
		}
	}

	// Iteration finished
	St.End();
	return false;
}

bool SLane::PermuteScrub(SLane* pClog, SLane* Rows)
{
	int i;
	// Start at Bottom of BStack
	for (level = missCnt - 1; level >= 0;) {
		pBlank = BStack[level];
		i = pBlank->i;

		if (Rows[i].Reaches(pClog->idx)) {
			if ((pBlank->laneMiss & pClog->needSet) != 0) {
				// Found a possible clog: should be the chosenBit
				if (pClog->needSet.Contains(pBlank->chosenBit)) {
					pClog->needSet -= pBlank->chosenBit;
					// Scrub will end for needSet exhausted
					if (pClog->needSet == 0)
						return true;
				}
			}
		}

		// No reach: move up
		level--;
	}

	// Level exhausted
	return false;
}

u64 SLane::PermuteCount()
{
	PermuteStart();

	while (PermuteStep())
		;

	permuteCnt = (int)foundCnt;
	return foundCnt;
}

bool SLane::VerifyPerm()
{
	bool success = true;
	Set perm = 0;
	for (int d = 0; d < missCnt; d++) {
		perm += BStack[d]->chosenBit;
		if ((BStack[d]->miss & BStack[d]->chosenBit) == 0)
			success = false;
	}
	if (perm != missing)
		success = false;

	return success;
}

void SLane::HistoInit()
{
	histoCnt = 0;
	for (int v = 0; v < n; v++) {
		Histo[v] = 0;
		HistoLastCol[v] = 0;
	}
}

void SLane::HistoAdd(Set s, int idx)
{
	Mask m = 1;
	for (int v = 0; v < n; v++) {
		if (s.Contains(m)) {
			Histo[v]++;
			HistoLastCol[v] = idx;
			histoCnt++;
		}
		m <<= 1;
	}
}

void SLane::HistoScan(SLane*& Rows, FastMatrix<6, u8>& Mat)
{
	int scanCnt = 0;
	Mask vMask;
	cout << "    Scan col [" << setw(2) << idx << "] ";
	for (int v = 0; v < n; v++) {
		scanCnt += Histo[v];
		vMask = Set::BitMask(v);
		if (missing.Contains(vMask)) {
			assert(Histo[v] > 0);
			if (Histo[v] <= 1) {
				// Forced value
				cout << setw(3) << v;

				// Change Mat and SLanes
				Mat[HistoLastCol[v]][idx] = v;
				missing -= vMask;
				for (level = 0; level < blankCnt; level++) {
					pBlank = BStack[level];
					if (Rows[pBlank->i].missing.Contains(vMask)) {
						Rows[pBlank->i].missing -= vMask;
					}
				}
			}
		}
	}
	if (scanCnt != histoCnt)
		cout << " CNT ERROR  histo " << histoCnt << " != scan " << scanCnt;
	cout << endl;
}

void SLane::FillBlanks(SLane*& Rows)
{
	for (level = 0; level < blankCnt; level++) {
		pBlank = BStack[level];
		pBlank->miss = missing & Rows[pBlank->i].missing;
		pBlank->missCnt = pBlank->miss.Count();
		//pBlank->origMiss = pBlank->miss;
		//pBlank->origCnt = pBlank->missCnt;
	}

	ComputeAvail();
}

void SLane::LinkBlanks(SLane*& Rows)
{
	for (int d = 0; d < blankCnt; d++) {
		pBlank = BStack[d];
		pBlank->LinkLeftOf(&Rows[pBlank->i].ringHd);
		Rows[pBlank->i].stops += Set::BitMask(pBlank->j);
	}
}

bool SolveEnv::Read(char* fname)
{
	IO.ReadOpen(fname);
	for (int i = 0; i < n; i++) {
		IO.ReadLine(Mat[i], 2, n);
	}

	return true;
}

bool SolveEnv::Dump(ostream& out, bool doSort, bool doRings)
{
	u8 buf[DIMMAX];
	for (int j = 0; j < n; j++)
		buf[j] = LaneTab[j].idx;
	IO.OutHeader(out, n, buf);

	IO.OutHeader(out, n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			buf[j] = doSort ? Mat[i][LaneTab[j].idx] : Mat[i][j];
		}
		IO.OutLineV(out, buf, i, n);
	}

	if (doRings) {
		out << endl << "  RINGS" << endl;
		BEntry* pEnt;
		for (int i = 0; i < n; i++) {
			out << "[" << setw(2) << i << "] ";
			for (pEnt = Rows[i].ringHd.rtLink; !pEnt->IsHead(); pEnt = pEnt->rtLink) {
				out << setw(3) << pEnt->j;
				assert(pEnt->i == i);
			}
			out << endl;
		}
	}

	return true;
}

void SolveEnv::ProcessMat()
{
	u8 v;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			v = Mat(i, j);
			if (v < n) {
				Rows[i].Present(v);
				Cols[j].Present(v);
			}
		}
	}

	for (int l = 0; l < n; l++) {
		Rows[l].Check();
		Cols[l].Check();
	}

	// Copy Mat for future verification
	MatCpy = Mat;
}

void SolveEnv::FillBlanks()
{
	// Create BStacks
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (Mat(i, j) > n) {
				Rows[i].AddBlank(i, j);
				Cols[j].AddBlank(i, j);
			}
		}
	}

	// Init ringHd for Rows
	for (int i = 0; i < n; i++) {
		Rows[i].ringHd.laneMiss = Rows[i].missing;
		Rows[i].ringHd.SetAsHead(i);
	}

	for (int j = 0; j < n; j++) {
		Cols[j].FillBlanks(Rows);
	}
}

// Link Cols based on sorted LaneTab
void SolveEnv::LinkBlanks()
{
	for (int l = 0; l < n; l++) {
		 LaneTab[l].pLane->LinkBlanks(Rows);
	}
}

bool LaneCompS(LaneRank<SLane> a, LaneRank<SLane> b)
{
	return a.permCnt < b.permCnt;
}

void SolveEnv::SortCols(ostream& out, bool doSort)
{
	for (int j = 0; j < n; j++) {
		LaneTab[j].permCnt = Cols[j].PermuteCount();
		LaneTab[j].pLane = &Cols[j];
		LaneTab[j].idx = j;
		out << " Col " << j << " PermCnt  " << LaneTab[j].permCnt << endl;
	}

	if (doSort) {
		std::sort(LaneTab, LaneTab + n, LaneCompS);

		out << endl;
		for (int j = 0; j < n; j++) {
			out << " Sorted " << setw(2) << LaneTab[j].idx
				<< " PermCnt  " << setw(5) << LaneTab[j].permCnt << endl;
		}
	}
	else {
		out << endl << " NO SORT" << endl;
	}
}

void SolveEnv::HistoInit()
{
	histoCnt = 0;
	for (int v = 0; v < n; v++) {
		Histo[v] = 0;
		HistoLastCol[v] = 0;
	}
}

void SolveEnv::HistoAdd(Set s, int idx)
{
	Mask m = 1;
	for (int v = 0; v < n; v++) {
		if (s.Contains(m)) {
			Histo[v]++;
			HistoLastCol[v] = idx;
			histoCnt++;
		}
		m <<= 1;
	}
}

int SolveEnv::HistoScan(ostream &out, int j)
{
	int scanCnt = 0;
	Mask vMask;
	int fixCnt = 0;
	for (int v = 0; v < n; v++) {
		scanCnt += Histo[v];
		vMask = Set::BitMask(v);
		if (Cols[j].missing.Contains(vMask)) {
			assert(Histo[v] > 0);
			if (Histo[v] <= 1) {
				// Forced value
				int i = HistoLastCol[v];
				if (fixCnt == 0)
					out << "    Scan col [" << setw(2) << j << "] ";
				fixCnt++;
				out << " row " << setw(2) << i << " v " << setw(3) << v;

				// Change Mat and SLanes
				Mat[i][j] = v;
				Cols[j].missing -= vMask;
				Cols[j].missCnt--;
				if (Rows[i].missing.Contains(vMask)) {
					Rows[i].missing -= vMask;
					Rows[i].missCnt--;
				}
			}
		}
	}
	if (scanCnt != histoCnt) {
		out << " CNT ERROR  histo " << histoCnt << " != scan " << scanCnt;
		fixCnt = -1;
	}

	if (fixCnt != 0)
		out << endl;

	return fixCnt;
}

int SolveEnv::HistoFill(ostream& out)
{
	out << endl << " FILL" << endl;

	int fixCnt = 0;
	for (int j = 0; j < n; j++) {
		HistoInit();
		for (int i = 0; i < n; i++) {
			if (Mat[i][j] > n) {
				// Blank entry
				HistoAdd(Rows[i].missing & Cols[j].missing, i);
			}
		}

		fixCnt += HistoScan(out, j);
	}

	return fixCnt;
}

bool SolveEnv::PublishSolution()
{
	bool success = true;
	for (int j = 0; j < n; j++) {
		if (!Cols[j].VerifyPerm())
			success = false;
	}
	solveCnt++;
	cout << " SOLUTION # " << solveCnt << endl;
	return success;
}

void SolveEnv::UnRestrictRows(SLane* pCol, int depth)
{
	BEntry* pBlank;
	BEntry* pNext;
	for (int d = 0; d <= depth; d++) {
		pBlank = pCol->BStack[d];
		pNext = pBlank->rtLink;
		if (RBuf[d].blankM != 0) {
			// Restore downstream
			pNext->laneMiss = RBuf[d].laneM;
			pNext->miss = RBuf[d].blankM;
		}
	}
}

bool SolveEnv::SpyDownStream(BEntry* pEnt)
{
	Set choice;
	Set availMask = pEnt->laneMiss;

	for (; !pEnt->IsHead(); pEnt = pEnt->rtLink) {
		choice = Cols[pEnt->j].missing & availMask;
		if (choice == 0)
			return false;
		if (choice.CountIsOne()) {
			// Only one possibility: restrict availMask
			availMask = availMask - choice;
		}
	}

	return true;
}

// Returns failure level
//
int SolveEnv::RestrictRows(SLane* pCol)
{
	BEntry* pBlank;
	BEntry* pNext;
	for (int d = 0; d < pCol->missCnt; d++) {
		pBlank = pCol->BStack[d];
		pNext = pBlank->rtLink;
		if (!pNext->IsHead()) {
			// Backup downstream
			RBuf[d].Load(pNext->laneMiss.mask, pNext->miss.mask);

			// Update Downstream
			pNext->laneMiss = pBlank->laneMiss & (~pBlank->chosenBit);
			pNext->miss =
				pNext->laneMiss & Cols[pNext->j].missing;
			if (pNext->miss == 0) {
				// This won't do: pNext is unviable
				UnRestrictRows(pCol, d);
				return d;
			}

			if (!SpyDownStream(pNext)) {
				// This won't do: downstream chain unviable
				UnRestrictRows(pCol, d);
				return d;
			}
		}
		else
			RBuf[d].Load(0, 0);
	}

	// Restriction was succesful
	return -1;
}

bool SolveEnv::UpdateEntries(SLane* pCol)
{
	int zzz = 0;
	pCol->St.badCnt = 0;
	Set allMask = 0;
	pCol->needCnt = 0;
	pCol->needSet = 0;

	// Update blanks for next column
	BEntry* pBlank;
	for (int d = 0; d < pCol->missCnt; d++) {
		pBlank = pCol->BStack[d];
		pBlank->miss =
			pBlank->laneMiss & pCol->missing;
		if (pBlank->miss == 0) {
			// Will take any of the original missings
			pCol->needSet |=
				(Rows[pBlank->i].missing & pCol->missing);
			pCol->needLevels[pCol->needCnt++] = d;
			pCol->St.badCnt++;
		}
		allMask |= pBlank->laneMiss;
	}

	if (pCol->needSet == 0) {
		// Look for Col wide needs
		pCol->needSet = allMask & pCol->missing;
		if (pCol->needSet != pCol->missing) {
			pCol->needSet ^= pCol->missing;
			pCol->St.badCnt += pCol->needSet.Count();
		}
		else {
			pCol->needSet = 0;
			pCol->needCnt = 0;
		}
	}

	if (pCol->St.badCnt > 1) {
		zzz += 1;
	}

	return pCol->needCnt <= 0 && pCol->needSet == 0;
}

void SolveEnv::RestoreRows(SLane* pCol)
{
	BEntry* pBlank;
	for (int d = 0; d < pCol->missCnt; d++, pBlank++) {
		pBlank = pCol->BStack[d];
		Rows[pBlank->i].missing |= pBlank->chosenBit;
	}
}

int SolveEnv::BackRow(int d)
{
	BEntry* pBlank;
	for (pBlank = pClog->BStack[d]; !pBlank->IsHead(); pBlank = pBlank->lfLink) {
		if (pClog->needSet.Contains(pBlank->chosenBit)) {
			pClog->needSet -= pBlank->chosenBit;
			return pBlank->level;
		}
	}
	return -1;
}

void SolveEnv::BacktrackRows()
{
	int d;
	BEntry* pEnt;
	BEntry* pPrev;
	for (int l = 0; l < pClog->needCnt; l ++) {
		d = pClog->needLevels[l];
		pEnt = pClog->BStack[d];
		for (;;) {
		}
		pPrev = pEnt;
	}
}

void SolveEnv::Backtrack()
{
	pColCur = LaneTab[--colLevel].pLane;
	while (colLevel >= 0) {
		if ((pColCur->missing & pClog->needSet) == 0) {
			if (colLevel > 0) {
				// This level is not involved in the clogging: skip it
				pColCur = LaneTab[--colLevel].pLane;
			}
			else
				return;
		}
		else {
			// Involved level: scrub Permute stack
			if (pColCur->PermuteScrub(pClog, Rows)) {
				// Scrub found a needed value
				return;
			}
			else {
				if (colLevel > 0) {
					// Level scrubbed, nothing found, so climb up
					pColCur = LaneTab[--colLevel].pLane;
				}
				else
					// At level 0: cannot backtrack any more
					return;
			}
		}
	}
}

void SolveEnv::SolveInit()
{
	pColCur = LaneTab[0].pLane;
	pColCur->PermuteStart();
	for (int s = 0; s < n; s++) {
		FailCnt[s] = 0;
		ClogCnt[s] = 0;
		LaneTab[s].pLane->St.Reset();
	}

	// Init laneMiss for all rows
	BEntry* pEnt;
	for (int i = 0; i < n; i++) {
		pEnt = Rows[i].ringHd.rtLink;
		if (! pEnt->IsHead())
			pEnt->laneMiss = Rows[i].missing;
	}
}

int SolveEnv::Solve()
{
	int depth;

	SolveInit();

	for (colLevel = 0; colLevel >= 0; ) {
		if (pColCur->PermuteStep()) {
			// Successful step
			if (colLevel >= n - 1) {
				// At bottom level: a solution has been found
				PublishSolution();
			}
			else {
				// Continue search down next level
				if ((depth = RestrictRows(pColCur)) < 0) {
					// Successful restriction
					pColCur = LaneTab[++colLevel].pLane;
					if ((depth = pColCur->ComputeAvail()) >= 0) {
						// Failed ComputeAvail: restart at failure depth
						pColCur = LaneTab[--colLevel].pLane;
						UnRestrictRows(pColCur, depth);
						pColCur->PermuteContinueAt(depth);
					} else
						pColCur->PermuteStart();
				}
				else {
					// Restart permute at failure depth
					pColCur->PermuteContinueAt(depth);
				}
			}
		}
		else {
			// Level has been exhausted
			if (colLevel > 0) {
				// Not on top: no more permutations at this level
				FailCnt[colLevel]++;
				pColCur->St.End();

				// Permute completed, climb up
				pColCur = LaneTab[--colLevel].pLane;
				//RestoreRows(pColCur);
			}
			else
				// At level 0: solve is done
				break;
		}
	}

	return solveCnt;
}

/////////////////////////////////////////////////////////////

SolveEnv SEnv(35);

int main(int argc, char** argv)
{
	SEnv.Read(argv[1]); ;
	SEnv.ProcessMat();

	ofstream dout("matdmp.txt");
	dout << "ORIGINAL MAT" << endl;
	SEnv.Dump(dout, false, false);
	while (SEnv.HistoFill(dout) > 0)
		;
	dout << endl << "FINAL MAT" << endl;
	SEnv.Dump(dout, false, false);

	SEnv.FillBlanks();

#if 0
	for (int j = 0; j < DIM; j++) {
		u64 cnt = SEnv.Cols[j].PermuteCount();
		cout << " Col " << j << " PermCnt  " << cnt << endl;
	}
#endif
	SEnv.SortCols(dout, true);
	SEnv.LinkBlanks();
	SEnv.Dump(cout, true, true);

	SEnv.Dump(dout, true, true);
	dout.close();

	SEnv.Solve();

	return 0;
}