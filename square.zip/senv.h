#pragma once
#include "latsq.h"

class BEntry {
public:
	BEntry() : lfLink(0), rtLink(0), miss(0), missCnt(0),
		// origMiss(0), origCnt(0), chosenVal(0),
		chosenBit(0), i(-1), j(-1), level(0)
	{}

	BEntry* lfLink, * rtLink;

	void SelfLink() {
		lfLink = this;
		rtLink = this;
	}

	void LinkLeftOf(BEntry* pEnt) {
		rtLink = pEnt;
		lfLink = pEnt->lfLink;
		lfLink->rtLink = this;
		pEnt->lfLink = this;
	}

	Set miss;
	int missCnt;

	Set laneMiss;
	//Set origMiss;
	//int origCnt;

	Set choiceSet;
	Mask chosenBit;
	//u8 chosenVal;

	Set selectedSet;
	Set availForSelect;
	Set unSelected;

	bool IsHead() { return level < 0; }
	void SetAsHead(int i = -1) { SetLevel(-1); }

	int i, j;
	int level;
	void SetLevel(int lvl) { level = lvl; }
	void SetCoords(int _i, int _j) {
		i = _i;
		j = _j;
	}

	// BStack traversing
	enum {
		TOP = -1,
		BOT = DIMMAX,
		INVALID = -DIMMAX
	};

	int dnTrav;
	int upTrav;
};

class Stats {
public:
	Stats() {}

	void Init() {
		starts = 0;
		InitPass();
	}

	void Reset() {
		InitPass();
		starts = 0;
	}

	void InitPass() {
		starts++;
		steps = 0;
		ends = 0;
		exhausts = 0;
		select = 0;
	}

	void Step() { steps++; }
	void End() { ends++; }
	void Exhaust() { exhausts++; }
	void Select() { select++; }

	int starts;
	int steps;
	int ends;
	int exhausts;
	int select;
	int badCnt;
};

static const int BLANKCNTMAX = 16;

class SLane {
public:
	SLane() {}
	SLane(int _n) : n(_n) {}

	void Init(int _n, int _idx) {
		n = _n;
		idx = _idx;
		assert(n < DIMMAX - 2);
		all = Set::BitMask(n) - 1;
		missing = all;
		present = 0;
		presCnt = 0;
		missCnt = n;
		stops = 0;
		blankCnt = 0;
		ringHd.SelfLink();

		St.InitPass();
		St.starts = 0;
	}

	int n;
	int idx;

	Set present;
	int presCnt;
	Set missing;
	int missCnt;
	Mask all;

	Set needSet;
	int needCnt;
	u8 needLevels[BLANKCNTMAX];

	Set stops;
	bool Reaches(int j) { return stops.Contains(j); }

	u8 Histo[DIMMAX];
	u8 HistoLastCol[DIMMAX];
	int histoCnt;
	void HistoInit();
	void HistoAdd(Set s, int idx);
	void HistoScan(SLane*& Rows, FastMatrix<6, u8>& Mat);

	BEntry ringHd;

	BEntry* BStack[DIMMAX];
	int blankCnt;
	void AddBlank(int i, int j);
	void FillBlanks(SLane*& Rows);

	// Link Cols based on sorted LaneTab
	void LinkBlanks(SLane*& Rows);

	void Present(u8 v);
	void Missing(u8 v);
	bool Check();

	int ComputeAvail();

	u64 foundCnt;
	BEntry* pBlank;
	int level;

	int startLevel;
	Set preSelected;
	bool PermuteStart();
	bool PermuteStep();
	bool PermuteStartStk();
	bool PermuteStepStk();
	void PermuteContinueAt(int depth);
	bool PermuteScrub(SLane* pClog, SLane* Rows);

	bool VerifyPerm();

	u64 PermuteCount();
	int permuteCnt;


	Stats St;
};

class RestrictBuf {
public:
	RestrictBuf() {}

	void Load(Mask _laneM, Mask _blankM) {
		laneM = _laneM;
		blankM = _blankM;
	}

	Mask laneM;
	Mask blankM;
};

class SolveEnv {
public:
	SolveEnv(int _n) : n(_n)
	{
		Rows = new SLane[n];
		Cols = new SLane[n];

		for (int l = 0; l < n; l++) {
			Rows[l].Init(n, l);
			Cols[l].Init(n, l);
		}
	}

	int n;
	InOut<u8> IO;

	FastMatrix<6, u8> Mat;
	FastMatrix<6, u8> MatCpy;
	SLane* Rows;
	SLane* Cols;

	bool Read(char* fname);
	bool Dump(ostream& out, bool doSort, bool doRings);
	void ProcessMat();
	void FillBlanks();

	void LinkBlanks();

	LaneRank<SLane> LaneTab[DIMMAX];
	void SortCols(ostream& out, bool doSort = true);

	int solveCnt;
	int colLevel;
	SLane* pColCur;
	SLane* pClog;

	int Solve();
	void SolveInit();
	bool PublishSolution();
	int FailCnt[DIMMAX];
	int ClogCnt[DIMMAX];

	RestrictBuf RBuf[BLANKCNTMAX];

	int RestrictRows(SLane* pCol);
	bool SpyDownStream(BEntry* pEnt);
	void UnRestrictRows(SLane* pCol, int depth);
	void RestoreRows(SLane* pCol);
	bool UpdateEntries(SLane* pCol);

	void Backtrack();
	void BacktrackRows();
	int BackRow(int d);

	u8 Histo[DIMMAX];
	u8 HistoLastCol[DIMMAX];
	int histoCnt;
	void HistoInit();
	void HistoAdd(Set s, int idx);
	int HistoScan(ostream& out, int j);
	int HistoFill(ostream& out);

};

